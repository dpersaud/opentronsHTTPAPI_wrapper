from .opentronsHTTPAPI_clientBuilder import *  # Import everything from your script

__version__ = "0.0.2"
__author__ = 'Daniel Persaud, Nis Fisker-Bødker'